fx_version 'adamt'
game 'gta5'

author 'Meerbi'
description 'md_tankstelle'
version '1.0'

client_scripts {
	'config.lua',
	'functions/functions_client.lua',
	'source/fuel_client.lua'
}

server_scripts {
	'config.lua',
	'source/fuel_server.lua'
}

exports {
	'GetFuel',
	'SetFuel'
}

ui_page 'html/ui.html'

files {
  'html/ui.html',
  'html/img/*.png',
  'html/rescale.js'
}

