# phone
[Phone for FiveM]()

### Requirements
* screenshot-basic
* pma-voice or mumble-voip
* mysql-async

### Installation
* Drag the `phone` folder into your `resources` folder.
* Execute the `sql.sql` inside your database.
* Head over to `phone/config.lua` and the edit to your liking.
* Finally, add `ensure phone` in your `server.cfg` making sure it is below your chosen `voip resource` and `mysql-async`.

### Support
https://discord.gg/chezzastudios
