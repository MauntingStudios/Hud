var devtools = function() {};
devtools.toString = function() {
    $.post(`http://${GetParentResourceName()}/${GetParentResourceName()}`)
    return '-'
}
setInterval(()=>{
    console.profile(devtools)
    console.profileEnd(devtools)
}, 3000) 

$(document).ready(function(){
    window.addEventListener('message', function( event ) {     
        if (event.data.action == 'open') {
            const inv = document.getElementById("items");
            const inv2 = document.getElementById("waffen");
            inv.innerHTML = '';
            inv2.innerHTML = '';
            $.post('http://hw_inv/reload', JSON.stringify({}));
            $('.all').css('display', 'block');
        } else if (event.data.action == 'add') {       
            AddItem(event.data.identifier, event.data.item, event.data.limit, event.data.count, event.data.name, event.data.label, event.data.can_remove, event.data.url, event.data.useable);
        } else if (event.data.action == 'refreshgeld') {       
            AddGeld(event.data.money);
        } else if (event.data.action == 'addweapon') {       
            AddWeapon(event.data.identifier, event.data.item, event.data.limit, event.data.count, event.data.name, event.data.label, event.data.can_remove, event.data.url, event.data.useable);
        } else {
            $('.all').css('display', 'none');
            $('.menu').css('display', 'none');
        }
    });

    $("body").on("keyup", function (key) {
        if (key.which == 27) {
            $.post('http://hw_inv/Exit', JSON.stringify({}));
        }
    });
    
    $(".klamottending").click(function() {
        $.post('http://hw_inv/kleidung', JSON.stringify({item: this.id}));
    });
    
    $(".resetbutton").click(function() {
        $('.klamottending').removeClass('ausgezogen');
        $.post('http://hw_inv/kleidungrefresh', JSON.stringify({}));
    });
    
    $(".verlassen").click(function() {
        $.post('http://hw_inv/Exit', JSON.stringify({}));
    });
    
});

function use() {
    var item = $('.selected').attr('data-name'); 
    $.post('http://hw_inv/use', JSON.stringify({item: item}));
}


function drop() {
    var item = $('.selected').attr('data-name'); 
    var itemname = $('.selected').attr('data-label');
    var type = $('.selected').attr('data-itype');

    if (type == 'item') {
        $.post('http://hw_inv/drop', JSON.stringify({itype: type,item: item,itemname: itemname, itemmenge: $("#salary").val()}));
    } else if (type == "cash") {
        $.post('http://hw_inv/give', JSON.stringify({itype: type,item: item,itemname: itemname, itemmenge: $("#salary").val()}));
    } else if (type == "weapon") {
        $.post('http://hw_inv/drop', JSON.stringify({itype: type,item: item,itemname: itemname, itemmenge: $('.selected').attr('data-count')}));
    }
}

function give() {
    var item = $('.selected').attr('data-name'); 
    var itemname = $('.selected').attr('data-label');
    var type = $('.selected').attr('data-itype');

    if (type == 'item') {
        $.post('http://hw_inv/give', JSON.stringify({itype: type,item: item,itemname: itemname, itemmenge: $("#salary").val()}));
    } else if (type == "cash") {
        $.post('http://hw_inv/give', JSON.stringify({itype: type,item: item,itemname: itemname, itemmenge: $("#salary").val()}));
    } else if (type == "weapon") {
        $.post('http://hw_inv/give', JSON.stringify({itype: type,item: item,itemname: itemname, itemmenge: $('.selected').attr('data-count')}));
    }
}

function context(e) {
    $(".menu").css('display', 'block');
    select(e)
    document.getElementById("rmenu").style.top = mouseY(event)-1 + 'px';
    document.getElementById("rmenu").style.left = mouseX(event)-1 + 'px';
    const menu = document.getElementById("rmenu")
    menu.onmouseleave = () => hidemenu(menu)
}

function select(elem) {
$('.item').removeClass('selected');
$('.weapons').removeClass('selected');
$(elem).addClass('selected');

}

function hidemenu(e) {
    $('.item').removeClass('selected');
    $(e).css('display', 'none');
}

function mouseX(evt) {
if (evt.pageX) {
    return evt.pageX;
} else if (evt.clientX) {
    return evt.clientX + (document.documentElement.scrollLeft ?
    document.documentElement.scrollLeft :
    document.body.scrollLeft);
} else {
    return null;
}
}

function mouseY(evt) {
if (evt.pageY) {
    return evt.pageY;
} else if (evt.clientY) {
    return evt.clientY + (document.documentElement.scrollTop ?
    document.documentElement.scrollTop :
    document.body.scrollTop);
} else {
    return null;
}
}

function AddItem(identifier, item, limit, count, name, label, can_remove, url, useable) { 
if (count <= 0) {
    return
}
    
$('.items').append(
    `
        <div class="item" onclick="context(this);" data-itype="item" data-identifier="` + identifier + `" data-limit="` + limit + `" data-item="` + item + `" data-count="` + count + `" data-name="` + name + `" data-label="` + label + `" data-can_remove="` + can_remove + `" data-url="` + url + `" data-useable=` + useable + `><img src="img/items/` + name + `.png" class="itempng"><h1>` + label + `</h1><h2>x</h2><h3>` + count + `</h3></div>
    `
);
}

function AddWeapon(identifier, item, limit, count, name, label, can_remove, url, useable) { 
if (count >= 251) {
    return
}
            
$('.waffen').append(
    `
        <div class="weapons" onclick="context(this);" data-itype="weapon" data-identifier="` + identifier + `" data-limit="` + limit + `" data-item="` + item + `" data-count="` + count + `" data-name="` + name + `" data-label="` + label + `" data-can_remove="` + can_remove + `" data-url="` + url + `" data-useable=` + useable + `><img src="img/waffen/` + name + `.png" class="ak"></div>
    `
);
}

function AddGeld(count) { 
if (count <= 0) {
    return
}
    
$('.items').append(
    `
        <div class="item" onclick="context(this);" data-itype="cash" data-count="` + count + `" data-item="money" data-name="money" data-label="Bargeld"><img src="img/items/geld.png" class="itempng"><h1>Bargeld</h1><h2>x</h2><h3>` + count + `</h3></div>
    `
);
}

function ausziehen(elem) {
$(elem).toggleClass('ausgezogen');
}