fx_version 'adamant'
game 'gta5'

author '*-*'
description ''


version '0.0.1'

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'server/main.lua'
}

client_scripts {
	'client/main.lua'
}

ui_page 'html/inventar.html'
files {
  'html/*.png',
  'html/**/*.png',
  'html/fonts/BARLOW-600ITALIC.TTF',
  'html/fonts/MONTSERRAT-MEDIUMITALIC.TTF',
  'html/**/*.otf',
  'html/*.ttf', 
  'html/*.otf', 
  'html/*.css', 
  'html/*.js',
  'html/inventar.html'
}


dependencies {
	'es_extended'
}


