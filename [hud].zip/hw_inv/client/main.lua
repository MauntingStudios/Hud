local Keys = {
    ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
    ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
    ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
    ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
    ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
    ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
    ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
    ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
    ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}
  
ESX = nil
local geldlocal = 0
  
ESX = exports['es_extended']:getSharedObject()

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
  
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
  
    ESX.PlayerData = ESX.GetPlayerData()
end)
  
RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    ESX.PlayerData.job = job
end)
  
RegisterNetEvent('esx:setFrak')
AddEventHandler('esx:setFrak', function(frak)
    ESX.PlayerData.frak = frak
end)
  
RegisterNetEvent('esx:setFrakrank')
AddEventHandler('esx:setFrakrank', function(frakrank)
    ESX.PlayerData.frakrank = frakrank
end)

RegisterNetEvent('esx:setLevel')
AddEventHandler('esx:setLevel', function(level)
    ESX.PlayerData.level = level
end)

RegisterNetEvent('esx:setRP')
AddEventHandler('esx:setRP', function(rp)
    ESX.PlayerData.rp = rp
end)

RegisterNUICallback('Exit', function(data, cb)
    toggleField(false)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('reload', function(data, cb)
    ReloadInventory()
    cb('ok')
end)
  
local enableField = false
function toggleField(enable)
    SetNuiFocus(enable, enable)
    enableField = enable

    if enable then
        SendNUIMessage({
            action = 'open'
        }) 
    else
        SendNUIMessage({
            action = 'close'
        }) 
    end
end
  
RegisterNetEvent('hw_inv:openMenu')
AddEventHandler('hw_inv:openMenu', function()
    toggleField(true)
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer) 
    local data = xPlayer
    local accounts = data.accounts
    for k, v in pairs(accounts) do
        local account = v
        if account.name == "money" then

            SendNUIMessage({
                action = "refreshgeld",
                money = account.money
            })
            geldlocal = account.money
        end
    end
end)
  
RegisterNetEvent('esx:setAccountMoney')
AddEventHandler('esx:setAccountMoney', function(account)
    if account.name == "money" then

        SendNUIMessage({
            action = "refreshgeld",
            money = account.money
        })
        geldlocal = account.money
    end
end)

function ReloadInventory()
    SendNUIMessage({
        action = "refreshgeld",
        money = geldlocal
    })

    ESX.TriggerServerCallback('hw_inv:Inventarladen', function(data1,data2, money)
        for key, value in pairs(data1) do
            SendNUIMessage({
                action = "add",
                identifier = value.identifier,
                item = value.item,
                count = value.count,
                name = value.name,
                label = value.label,
                limit = value.weight,
                can_remove = value.can_remove,
                url = value.name,
                useable = value.usable
            })
        end

        for key, value in pairs(data2) do
            SendNUIMessage({
                action = "addweapon",
                identifier = value.identifier,
                item = value.item,
                count = value.ammo,
                name = value.name,
                label = value.label,
                can_remove = value.can_remove,
                url = value.name,
            })
        end

        SendNUIMessage({
            action = "refreshgeld",
            money = money
        })
    end, GetPlayerServerId(PlayerId()))
end
  
function loadAnimDict(dict)
    while (not HasAnimDictLoaded(dict)) do
        RequestAnimDict(dict)
        Citizen.Wait(5)
    end
end
  
RegisterNUICallback('use', function(data, cb)
    toggleField(false)
    TriggerServerEvent("esx:useItem", data.item)
    cb('ok')
end)
  
local hat = false
local mask = false
local brille = false
local chain = false
local torso = false
local tshirt = false
local hose = false
local boots = false
local backpack = false

RegisterNUICallback('kleidung', function(data, cb)
    --print(data.item)

    if data.item == "hat" then
        ExecuteCommand("hut")
    elseif data.item == "mask" then
        ExecuteCommand("maske")
    elseif data.item == "brille" then
        ExecuteCommand("brille")
    elseif data.item == "chain" then
        ExecuteCommand("hals")
    elseif data.item == "torso" then
        ExecuteCommand("hemd")
    elseif data.item == "weste" then
        ExecuteCommand("weste")
    elseif data.item == "hose" then
        ExecuteCommand("hose")
    elseif data.item == "boots" then
        ExecuteCommand("schuhe")
    elseif data.item == "armband" then
        ExecuteCommand("armband")
    elseif data.item == "handschuhe" then
        ExecuteCommand("handschuhe")
    elseif data.item == "hemd" then
        ExecuteCommand("oberteil")
    elseif data.item == "backpack" then
        ExecuteCommand("rucksack")
    end

    cb('ok')
end)
  
RegisterNUICallback('kleidungrefresh', function(data, cb)
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
        TriggerEvent('skinchanger:loadSkin', skin)
    end)

    cb('ok')
    toggleField(false)
end)
  
RegisterNUICallback("drop", function(data, cb)
    toggleField(false)
    local playerPed = GetPlayerPed(-1)
    if IsPedSittingInAnyVehicle(playerPed) then
        return
    end

    local ped = PlayerPedId()
    if (IsPedInAnyVehicle(ped, true) == false) then
        if data.itype == "weapon" then
            TriggerServerEvent("esx:removeInventoryItem", "item_weapon", data.item, data.itemmenge, GetPlayerServerId(PlayerId()))
        elseif data.itype == "cash" then
            TriggerServerEvent("esx:removeInventoryItem", "item_account", data.item, tonumber(data.itemmenge), GetPlayerServerId(PlayerId()))
        else
            TriggerServerEvent("esx:removeInventoryItem", "item_standard", data.item, tonumber(data.itemmenge), GetPlayerServerId(PlayerId()))
        end

        loadAnimDict('anim@mp_snowball')
        TaskPlayAnim(PlayerPedId(), 'anim@mp_snowball', 'pickup_snowball', 8.0, -1, -1, 0, 1, 0, 0, 0)

        Citizen.Wait(1300)
        ClearPedTasksImmediately(playerPed) 

        cb("ok")
    else
        -- print("Nicht im Fahrzeug")
    end
end)

RegisterNUICallback("give", function(data, cb)
    toggleField(false)
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()

    if closestDistance ~= -1 and closestDistance <= 3 then
        local closestPed = GetPlayerPed(closestPlayer)

        if not IsPedSittingInAnyVehicle(closestPed) then
            if tonumber(data.itemmenge) > 0 then
                if data.itype == "weapon" then
                    TriggerServerEvent('esx:giveInventoryItem', GetPlayerServerId(closestPlayer), 'item_standard', data.item, tonumber(data.itemmenge), GetPlayerServerId(PlayerId()))
                elseif data.itype == "cash" then
                    TriggerServerEvent('esx:giveInventoryItem', GetPlayerServerId(closestPlayer), 'item_money', data.item, tonumber(data.itemmenge), GetPlayerServerId(PlayerId()))
                else
                    TriggerServerEvent('esx:giveInventoryItem', GetPlayerServerId(closestPlayer), 'item_standard', data.item, tonumber(data.itemmenge), GetPlayerServerId(PlayerId()))
                end
            else
                ESX.ShowNotification("Falsche Menge")
            end
        else
            ESX.ShowNotification("Im Fahrzeug kannst an niemanden der im Fahrzeug sitzt etwas geben")
        end
    else
        ESX.ShowNotification("Keine Person in der Nähe")
    end	
end)
  
-- Inventar Hotkey

Citizen.CreateThread(function()
    Citizen.Wait(1000)
    while true do
        Citizen.Wait(1)
        if IsControlJustPressed(0, 289) then
            TriggerEvent("hw_inv:openMenu")
        end
    end
end)