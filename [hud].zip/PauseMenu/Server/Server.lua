
RegisterServerEvent('pausemenu:quit')
AddEventHandler('pausemenu:quit', function()
DropPlayer(source,"Server Verlassen!")

end)