fx_version 'cerulean'
game 'gta5'

author 'ToastinYou'
version '2.3.0'

client_script 'NoReticle.Client.net.dll'
server_script 'NoReticle.Server.net.dll'